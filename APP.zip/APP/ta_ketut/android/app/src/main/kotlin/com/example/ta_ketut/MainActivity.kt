package com.example.ta_ketut

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
