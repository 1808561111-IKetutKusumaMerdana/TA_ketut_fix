# Image-Steganography---Digital-Watermarking-to-Hide-Text-Messages
## Authors:
### Tanya Yadav
### Shaina Mehta
 
 Output-
 
 ![alt tag](https://github.com/Tanya-yadav/Image-Steganography---Digital-Watermarking-to-Hide-Text-Messages---Networking-5th-Sem-Project/blob/main/Assignment/Screenshot%20(20).png)

 ![alt tag](https://github.com/Tanya-yadav/Image-Steganography---Digital-Watermarking-to-Hide-Text-Messages---Networking-5th-Sem-Project/blob/main/Assignment/Screenshot%20(17).png)
 
 ![alt tag](https://github.com/Tanya-yadav/Image-Steganography---Digital-Watermarking-to-Hide-Text-Messages---Networking-5th-Sem-Project/blob/main/Assignment/Screenshot%20(18).png)
 
  ![alt tag](https://github.com/Tanya-yadav/Image-Steganography---Digital-Watermarking-to-Hide-Text-Messages---Networking-5th-Sem-Project/blob/main/Assignment/Screenshot%20(21).png)
 
 
## Acknowlegdements:
### Unsung Heros of Stack Overflow, Github, NPTEL Course, Wikipedia, Edureka, Wikipedia, Towards Data Science and other Web Blogs and Youtube Videos.

## What the Project is all about?
##### This project is based on image steganography using DCT and AES encryption system.

## What is Image Watermarking?
Digital Watermarking is use of a kind of marker convert embedded in a digital media such as audio, video or image which enables us to know the source or owner of the copyright. This technique is used for tracing copyright infringement in social media and knowing the genuineness of the notes in the banking system.

##### 
## What is Image Steganography?
Image Steganography is the process of hiding information which can be text, image or video inside a cover image. The secret information is hidden in a way that it not visible to the human eyes. 

##### 
